<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$username = trim(readline('নতুন অ্যাডমিন username: '));
if ($username === '' || strlen($username) > 80) { fwrite(STDERR,"Username 1–80 অক্ষরের হতে হবে.\n"); exit(1); }
fwrite(STDOUT, 'নতুন অ্যাডমিন password (কমপক্ষে 12 অক্ষর): ');
if (function_exists('shell_exec')) @shell_exec('stty -echo');
$password = trim((string)fgets(STDIN));
if (function_exists('shell_exec')) @shell_exec('stty echo');
fwrite(STDOUT,"\n");
if (strlen($password) < 12) { fwrite(STDERR,"Password কমপক্ষে 12 অক্ষরের দিন.\n"); exit(1); }
$pdo = db();
$pdo->exec("CREATE TABLE IF NOT EXISTS panel_admins (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$stmt=$pdo->prepare('INSERT INTO panel_admins (username,password_hash) VALUES (?,?)');
$stmt->execute([$username,password_hash($password,PASSWORD_DEFAULT)]);
fwrite(STDOUT,"অ্যাডমিন অ্যাকাউন্ট তৈরি হয়েছে।\n");
