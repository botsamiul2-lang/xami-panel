<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
start_secure_session();
const DB_TABLES = ['5d','admin','balance_transfer','bank_recharge','crashbetrecord','financial_details','k3','level','minutes_1','point_list','recharge','redenvelopes','redenvelopes_used','result_5d','result_k3','roses','salary','turn_over','users','user_bank','wingo','withdraw'];
function get_schema(string $table): array {
    if (!in_array($table, DB_TABLES, true)) throw new RuntimeException('Unknown table');
    $stmt = db()->query("SHOW COLUMNS FROM `".$table."`");
    return $stmt->fetchAll();
}
function is_private_column(string $name): bool {
    return (bool)preg_match('/password|token|otp|secret|api.?key/i', $name);
}
function cell_text($value): string {
    $value=(string)$value;
    if (function_exists('mb_strimwidth')) return mb_strimwidth($value,0,90,'…','UTF-8');
    return strlen($value)>180 ? substr($value,0,177).'…' : $value;
}
function schema_primary_key(array $schema): string {
    foreach ($schema as $col) if (($col['Key'] ?? '') === 'PRI') return $col['Field'];
    foreach ($schema as $col) if ($col['Field'] === 'id') return 'id';
    throw new RuntimeException('This table has no supported primary key.');
}
function table_label(string $table): string {
    $labels=['5d'=>'5D গেম','admin'=>'সিস্টেম সেটিংস','balance_transfer'=>'ব্যালেন্স ট্রান্সফার','bank_recharge'=>'ব্যাংক রিচার্জ সেটিংস','crashbetrecord'=>'Crash Bet','financial_details'=>'আর্থিক হিসাব','k3'=>'K3 গেম','level'=>'লেভেল সেটিংস','minutes_1'=>'মিনিট গেম বেট','point_list'=>'পয়েন্ট তালিকা','recharge'=>'রিচার্জ','redenvelopes'=>'রেড এনভেলপ','redenvelopes_used'=>'ব্যবহৃত এনভেলপ','result_5d'=>'5D বেট/ফলাফল','result_k3'=>'K3 বেট/ফলাফল','roses'=>'রেফারেল/রোজেস','salary'=>'কমিশন/সেলারি','turn_over'=>'টার্নওভার','users'=>'ব্যবহারকারী','user_bank'=>'ব্যবহারকারীর ব্যাংক','wingo'=>'Wingo রেকর্ড','withdraw'=>'উত্তোলন'];
    return $labels[$table] ?? $table;
}
$page = $_GET['page'] ?? 'dashboard';
if ($page === 'logout') { header('Location: ?page=dashboard'); exit; }
if ($page !== 'login') require_login();
if ($page !== 'login' && $_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='logout') {
    verify_csrf(); $_SESSION=[]; session_destroy(); header('Location: ?page=login'); exit;
}
$error='';
if ($page==='login' && $_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf(); $username=trim((string)($_POST['username']??'')); $password=(string)($_POST['password']??'');
    try {
        $s=db()->prepare('SELECT id,username,password_hash FROM panel_admins WHERE username=? LIMIT 1'); $s->execute([$username]); $admin=$s->fetch();
        if ($admin && password_verify($password,$admin['password_hash'])) { session_regenerate_id(true); $_SESSION['admin_id']=$admin['id']; $_SESSION['admin_name']=$admin['username']; header('Location: ?page=dashboard'); exit; }
        $error='লগইন তথ্য সঠিক নয়।';
    } catch(Throwable $e) { $error='অ্যাডমিন লগইন সেটআপ পাওয়া যায়নি। README অনুযায়ী setup_admin.php চালান।'; }
}
$table=(string)($_GET['table']??''); $schema=[]; $pk=''; $notice='';
if ($page==='table') {
    try { $schema=get_schema($table); $pk=schema_primary_key($schema); }
    catch(Throwable $e) { http_response_code(404); $error='টেবিলটি পাওয়া যায়নি বা এই DB-তে নেই।'; $page='dashboard'; }
    if ($page==='table' && $_SERVER['REQUEST_METHOD']==='POST') {
        verify_csrf(); $action=$_POST['action']??'';
        try {
            if ($action==='delete') {
                $id=(string)($_POST['pk_value']??'');
                $stmt=db()->prepare("DELETE FROM `{$table}` WHERE `{$pk}`=? LIMIT 1"); $stmt->execute([$id]);
                $notice='রেকর্ড মুছে ফেলা হয়েছে।';
            } elseif ($action==='save') {
                $editId=(string)($_POST['pk_value']??''); $values=[];
                foreach($schema as $col) {
                    $field=$col['Field'];
                    if ($field===$pk) continue;
                    if (is_private_column($field) && trim((string)($_POST['fields'][$field]??''))==='') continue;
                    if (!array_key_exists($field,$_POST['fields']??[])) continue;
                    $value=$_POST['fields'][$field];
                    if (is_array($value)) throw new RuntimeException('Invalid field value.');
                    $value=(string)$value;
                    $values[$field]=($value==='' && ($col['Null']??'')==='YES') ? null : $value;
                }
                if (isset($_POST['is_edit']) && $_POST['is_edit']==='1') {
                    if ($values) { $set=implode(',',array_map(fn($c)=>"`$c`=?",array_keys($values))); $args=array_values($values); $args[]=$editId; $st=db()->prepare("UPDATE `{$table}` SET {$set} WHERE `{$pk}`=? LIMIT 1"); $st->execute($args); }
                    $notice='রেকর্ড আপডেট হয়েছে।';
                } else {
                    if (!$values) throw new RuntimeException('অন্তত একটি ফিল্ড দিন।');
                    $cols=array_keys($values); $marks=array_fill(0,count($cols),'?');
                    $st=db()->prepare('INSERT INTO `'.$table.'` (`'.implode('`,`',$cols).'`) VALUES ('.implode(',',$marks).')'); $st->execute(array_values($values));
                    $notice='নতুন রেকর্ড যোগ হয়েছে।';
                }
            }
        } catch(Throwable $e) { $error='কাজটি সম্পন্ন হয়নি। প্রয়োজনীয় ফিল্ড/ডেটা পরীক্ষা করুন; DB ত্রুটি সার্ভারের লগে দেখুন।'; }
    }
}
if (!in_array($page,['login','dashboard','table'],true)) $page='dashboard';
if ($page==='login' && !empty($_SESSION['admin_id'])) { header('Location: ?page=dashboard'); exit; }
$title=$page==='table'?table_label($table):($page==='login'?'অ্যাডমিন লগইন':'ড্যাশবোর্ড');
$mode=$_GET['mode']??'list'; $editRow=null; $rows=[]; $columns=[]; $q=trim((string)($_GET['q']??''));
if ($page==='table' && $mode==='edit' && isset($_GET['id'])) { try {$st=db()->prepare("SELECT * FROM `{$table}` WHERE `{$pk}`=? LIMIT 1");$st->execute([(string)$_GET['id']]);$editRow=$st->fetch();if(!$editRow)$error='রেকর্ড পাওয়া যায়নি।';}catch(Throwable $e){$error='রেকর্ড লোড করা যায়নি।';} }
if ($page==='table' && $mode==='list' && !$error) {
    try {
        $searchable=[]; foreach($schema as $col) if (!preg_match('/blob|binary/i',$col['Type']) && !is_private_column($col['Field'])) $searchable[]=$col['Field'];
        $where=''; $args=[];
        if($q!=='' && $searchable) { $where=' WHERE '.implode(' OR ',array_map(fn($c)=>"CAST(`$c` AS CHAR) LIKE ?",$searchable)); foreach($searchable as $_)$args[]='%'.$q.'%'; }
        $sql="SELECT * FROM `{$table}`{$where} ORDER BY `{$pk}` DESC LIMIT 100";
        $st=db()->prepare($sql);$st->execute($args);$rows=$st->fetchAll();$columns=array_map(fn($c)=>$c['Field'],$schema);
    } catch(Throwable $e) {$error='রেকর্ডগুলো লোড করা যায়নি।';}
}
?><!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($title)?> · XAMI</title><link rel="stylesheet" href="style.css"></head><body>
<?php if($page==='login'):?><main class="login-wrap"><section class="login-card"><div class="brand-mark">X</div><h1>XAMI Admin</h1><p>আপনার তৈরি করা প্যানেল অ্যাডমিন অ্যাকাউন্ট ব্যবহার করুন।</p><?php if($error):?><div class="alert"><?=h($error)?></div><?php endif?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>Username<input name="username" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button class="primary full">লগইন</button></form></section></main>
<?php else:?><div class="layout"><aside class="sidebar"><div class="brand"><span class="brand-mark">X</span><span>XAMI<small>Management Console</small></span></div><nav><a class="<?= $page==='dashboard'?'active':''?>" href="?page=dashboard"><span>ড্যাশবোর্ড</span></a><div class="nav-label">DATABASE TABLES (<?=count(DB_TABLES)?>)</div><?php foreach(DB_TABLES as $t):?><a class="<?= $page==='table'&&$table===$t?'active':''?>" href="?page=table&amp;table=<?=rawurlencode($t)?>"><span><?=h(table_label($t))?></span></a><?php endforeach?></nav><form method="post" class="logout"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="logout"><button>লগ আউট</button></form></aside><main class="main"><header class="topbar"><div><span class="eyebrow">XAMI · ADMIN</span><h1><?=h($title)?></h1></div><div class="admin-pill"><span class="dot"></span><?=h($_SESSION['admin_name']??'Admin')?></div></header>
<?php if($notice):?><div class="success"><?=h($notice)?></div><?php endif?><?php if($error):?><div class="alert"><?=h($error)?></div><?php endif?>
<?php if($page==='dashboard'):?><section class="welcome"><div><span class="eyebrow light">DATABASE OVERVIEW</span><h2>XAMI অ্যাডমিন কনসোলে স্বাগতম</h2><p>SQL ডাম্পে থাকা ২২টি টেবিলের তথ্য এখান থেকে দেখা ও পরিচালনা করুন। যেকোনো পরিবর্তন সরাসরি সংযুক্ত ডেটাবেসে প্রয়োগ হবে।</p></div><div class="welcome-icon">◈</div></section><div class="notice"><strong>গুরুত্বপূর্ণ:</strong> সেভ/ডিলিট করলে সংযুক্ত ডেটাবেসে সঙ্গে সঙ্গে পরিবর্তন হবে। আগে ব্যাকআপ নিন। পাসওয়ার্ড, টোকেন ও OTP তালিকায় আড়াল করা থাকে; ফর্মে ফাঁকা রাখলে অপরিবর্তিত থাকবে।</div><section class="cards"><?php foreach(DB_TABLES as $t):?><a class="stat stat-link" href="?page=table&amp;table=<?=rawurlencode($t)?>"><span><?=h(table_label($t))?></span><strong><?php try{$n=(int)db()->query("SELECT COUNT(*) FROM `{$t}`")->fetchColumn();echo number_format($n);}catch(Throwable $e){echo '—';}?></strong><small>রেকর্ড · খুলুন →</small></a><?php endforeach?></section>
<?php elseif($page==='table'):?><?php if(in_array($mode,['add','edit'],true)):?><section class="panel form-panel"><div class="panel-head"><div><h2><?=$mode==='edit'?'রেকর্ড সম্পাদনা':'নতুন রেকর্ড যোগ'?></h2><p>টেবিল: <?=h($table)?> · Primary key: <?=h($pk)?></p></div><a class="secondary" href="?page=table&amp;table=<?=rawurlencode($table)?>">← তালিকায় ফিরুন</a></div><form method="post" class="record-form" onsubmit="return confirm('এই রেকর্ডটি সংরক্ষণ করবেন?')"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="is_edit" value="<?=$mode==='edit'?'1':'0'?>"><input type="hidden" name="pk_value" value="<?=h($editRow[$pk]??'')?>"><?php foreach($schema as $col):$field=$col['Field'];if($field===$pk)continue;$private=is_private_column($field);$value=$private?'':($editRow[$field]??'');$type=preg_match('/int|decimal|float|double/i',$col['Type'])?'number':(str_contains(strtolower($col['Type']),'text')?'textarea':'text');?><label><?=h($field)?> <small><?=h($col['Type'])?><?=$col['Null']==='YES'?' · ঐচ্ছিক':''?></small><?php if($type==='textarea'):?><textarea name="fields[<?=h($field)?>]" rows="3" placeholder="<?=$private?'পরিবর্তন না করলে ফাঁকা রাখুন':''?>"><?=h($value)?></textarea><?php else:?><input name="fields[<?=h($field)?>]" type="<?=$private?'password':$type?>" value="<?=h($value)?>" <?=$private?'autocomplete="new-password" placeholder="পরিবর্তন না করলে ফাঁকা রাখুন"':''?> <?=$col['Null']!=='YES'&&!$private&&$mode==='add'?'required':''?> step="any"><?php endif?></label><?php endforeach?><div class="form-actions"><button class="primary">সংরক্ষণ</button><a class="secondary" href="?page=table&amp;table=<?=rawurlencode($table)?>">বাতিল</a></div></form></section><?php else:?><section class="panel"><div class="toolbar"><form class="search" method="get"><input type="hidden" name="page" value="table"><input type="hidden" name="table" value="<?=h($table)?>"><input name="q" value="<?=h($q)?>" placeholder="এই টেবিলে খুঁজুন"><button class="primary">খুঁজুন</button></form><a class="primary add-button" href="?page=table&amp;table=<?=rawurlencode($table)?>&amp;mode=add">＋ নতুন রেকর্ড</a></div><?php if(!$rows):?><div class="empty">রেকর্ড নেই বা মেলেনি।</div><?php else:?><div class="table-wrap"><table><thead><tr><?php foreach($columns as $c):?><th><?=h($c)?></th><?php endforeach?><th>অ্যাকশন</th></tr></thead><tbody><?php foreach($rows as $row):?><tr><?php foreach($columns as $c):?><td><?php if(is_private_column($c)):?><span class="masked">••••••</span><?php else:?><?=h(cell_text($row[$c]??''))?><?php endif?></td><?php endforeach?><td class="actions"><a href="?page=table&amp;table=<?=rawurlencode($table)?>&amp;mode=edit&amp;id=<?=rawurlencode((string)$row[$pk])?>">সম্পাদনা</a><form method="post" onsubmit="return confirm('সতর্কতা: এই রেকর্ড স্থায়ীভাবে মুছে যাবে। নিশ্চিত?')"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="pk_value" value="<?=h($row[$pk])?>"><button class="danger-link">মুছুন</button></form></td></tr><?php endforeach?></tbody></table></div><div class="table-foot">সর্বশেষ ১০০টি রেকর্ড · <?=count($rows)?> দেখানো হয়েছে · গোপনীয় ক্ষেত্র আড়াল করা</div><?php endif?></section><?php endif?><?php endif?><footer>XAMI Admin · শুধুমাত্র অনুমোদিত ডেটাবেসে ব্যবহার করুন</footer></main></div><?php endif?></body></html>
