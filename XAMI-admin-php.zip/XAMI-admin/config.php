<?php
declare(strict_types=1);

// Configure these as environment variables on your server. Never commit real credentials.
const DB_HOST = '127.0.0.1';
const DB_NAME = 'u225105215_king';
const DB_USER = 'CHANGE_ME';
const DB_PASS = 'CHANGE_ME';
const APP_NAME = 'XAMI Admin';

// Change DB_HOST/DB_NAME/DB_USER/DB_PASS above before installation.
function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function start_secure_session(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_set_cookie_params(['httponly'=>true, 'secure'=>!empty($_SERVER['HTTPS']), 'samesite'=>'Strict']);
        session_start();
    }
}
function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function require_login(): void {
    start_secure_session();
    if (empty($_SESSION['admin_id'])) { header('Location: ?page=login'); exit; }
}
function csrf_token(): string {
    start_secure_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    start_secure_session();
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(403); exit('Invalid request token');
    }
}
function table_count(string $table): int {
    $allowed = ['users','wingo','recharge','withdraw','result_5d','result_k3'];
    if (!in_array($table, $allowed, true)) return 0;
    try { return (int)db()->query("SELECT COUNT(*) FROM `$table`")->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}
