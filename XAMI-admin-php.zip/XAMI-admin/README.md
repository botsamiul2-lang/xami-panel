# XAMI Admin (PHP + MySQL)

XAMI is a PHP 8+ administration panel built against the supplied `tiranga.sql` database structure. It discovers and manages the 22 included tables: view/search the latest records, add records, edit records, and delete records. Admin access uses a separate password-hash login; it does not authenticate against customer records in the SQL dump.

## Requirements
- PHP 8.1+ with `pdo_mysql`
- MySQL or MariaDB
- The SQL database imported from a database you own or are authorized to administer

## Install
1. Back up your data. Import `tiranga.sql` into a **test database first** using MySQL/phpMyAdmin. The dump contains user and financial information; never expose or send it to an untrusted host.
2. Edit `config.php` and replace `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASS`. Grant the database user access only to this database. Keep credentials private.
3. From this project folder, run `php setup_admin.php`. Create a new unique username and a password of at least 12 characters. This creates a separate `panel_admins` table and stores a password hash. Do not reuse passwords from the SQL dump.
4. Set your web server document root to **`public/`**, not the project root. Use HTTPS before making the panel accessible over the Internet.
5. Open the site and sign in using the account created in step 3.

Local preview: `php -S 127.0.0.1:8080 -t public`.

## What is included
- Dashboard with record counts and navigation to all 22 SQL tables.
- Per-table record list, search, add, edit, and delete forms.
- Prepared SQL statements, HTML output escaping, CSRF tokens on POST operations, session cookie protections, and a confirmation step for delete.
- Password, token, OTP, and similar secret fields are masked in lists. On edit, keep such fields blank to leave them unchanged; newly entered values are hashed nowhere except where the underlying application's own logic handles them. This panel does not change password-hashing policy.

## Important
- **Add/edit/delete actions directly change the connected database.** Take a backup before use and do not connect this starter panel to a production database until reviewed and secured.
- This is a starter admin panel, not the original site's PHP source. The SQL dump only provided its database schema and records.
- Lists show at most 100 records per table. Filters search non-secret fields.
- Review access control, logging, HTTPS, rate limiting, backups, and all column-level permissions before production use. Use only systems and data you are authorized to manage and comply with applicable laws.
